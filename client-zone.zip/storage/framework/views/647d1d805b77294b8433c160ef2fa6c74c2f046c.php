  
    

    <?php $__env->startSection('title', 'AJI MIS | DASHBOARD'); ?>
    
    <?php $__env->startSection('content'); ?>
    <div class="auth-box h-full flex flex-col justify-center">
        <div class="mobile-logo text-center mb-6 lg:hidden flex justify-center">
            <div class="mb-10 inline-flex items-center justify-center">
                
                <span class="ltr:ml-3 rtl:mr-3 text-xl font-Inter font-bold text-slate-900 dark:text-white">DashCode</span>
            </div>
        </div>
        <div class="flex-col sm:flex items-center justify-center relative py-8 sm:py-10 lg:py-0">
            <div class="w-full px-4 sms:px-0 sm:w-[450px]">
                <div class="text-center">
                    <h4 class="font-medium">
                        <?php echo e($code); ?>

                    </h4>
                    <p>If you have click link verification <br>
                        <a href="<?php echo e(route('login-main')); ?>" style="color: blue">click here</a> to login
                    </p>

                   

                    
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.guest', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\sahril.aji00829\Documents\web\client-zone\resources\views/auth/verify-email.blade.php ENDPATH**/ ?>