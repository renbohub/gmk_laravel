@extends('layouts.app')

    @section('title', 'AJI MIS | DASHBOARD')
    
    @section('content')
    
    @endsection